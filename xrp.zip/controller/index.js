const RippleAPI = require('ripple-lib').RippleAPI;
const api = new RippleAPI({
    server: process.env.XRP_URI // Public rippled server hosted by Ripple, Inc.
});

api.on('error', (errorCode, errorMessage) => {
    console.log(errorCode + ': ' + errorMessage);
});
api.on('connected', () => {
    console.log('RIPPLE connected');

    //sample call
    // transferAmount('rNg5FfYdvi7gRbBzQ2oznUCL3DCbcuae9J', 'raHGZziDBmJmJFTYehvtXWFQxiwu1nvqAB', 20, { password: 'shALaLUr3c4u3SvtvQjX8z3n9uN41' }).then(console.log)
});
api.on('disconnected', (code) => {
    // code - [close code](https://developer.mozilla.org/en-US/docs/Web/API/CloseEvent) sent by the server
    // will be 1000 if this was normal closure
    console.log('RIPPLE disconnected, code:', code);
    connectRipple(console.log)
});

const connectRipple = (cb) => {
    api.connect().then(cb).catch(cb);
};

console.log('uri', process.env.XRP_URI)

const createWallet = async (req, res) => {
    try {
        let address = api.generateAddress();
        res.sendResponse({address}, 'Address created successfully.', 200);
    }
    catch (ex) {
        console.log(ex);
        res.sendError(ex, 'Failed to create address', 500);
    }
};

const getBalance = async (req, res) => {
    try {
        let result = await api.getBalances(req.params.address, { currency: 'XRP' });
        res.sendResponse(result[0].value, 'Get balance - success.', 200);
    }
    catch (ex) {
        console.log('ex', ex);
        res.sendResponse(0, 'Get balance - success.', 200);
    }
};

const transferAmount = async (req, res) => {
    let amount = String(req.body.amount);
    let payment = {
        "source": {
            "address": req.body.from,
            "maxAmount": {
                "value": amount,
                "currency": "XRP"
            }
        },
        "destination": {
            "address": req.body.to,
            "amount": {
                "value": amount,
                "currency": "XRP"
            }
        }
    };
    let result = await api.preparePayment(req.body.from, payment);
    const prepared = result.txJSON;
    const secret = req.body.password;
    sign = api.sign(prepared, secret);
    let tx = await api.submit(sign.signedTransaction)
    console.log('tx', tx);
    if(tx.engine_result_code != 0) {
        return res.sendError(tx, tx.engine_result_message, 500)
    } else {
        return res.sendResponse(tx.tx_json, 'Payment - success.', 200);
    }
}

const receive = (req, res) => {
    api.getLedger()
    .then((ledger) => {
        api.getLedger({
            ledgerVersion: ledger.ledgerVersion,
            includeAllData: true,
            includeTransactions: true
        }).then(ledger => {
            if (ledger.transactions && ledger.transactions.length > 0) {
                ledger.transactions && ledger.transactions.forEach(async (item, index) => {
                    if(index == ledger.transactions.length - 1 && !item.outcome.deliveredAmount || item.outcome.deliveredAmount.currency !== 'XRP') return res.sendResponse([], 'Receive payment.', 200);
                    if(index == ledger.transactions.length - 1) return res.sendResponse(item, 'Receive payment.', 200);
                });
            } else {
                return res.sendResponse([], 'Receive payment.', 200);
            }
        });
    })
}


module.exports = {
    createWallet
    , getBalance
    , transferAmount
    , connectRipple
    , receive
};