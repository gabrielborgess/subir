const StellarSdk = require('stellar-sdk');
const stellarServer = new StellarSdk.Server(process.env.XLM_URI);
StellarSdk.Network.useTestNetwork();

const receive = async (req, res) => {
    stellarServer.payments()
    .call()
    .then(function (paymentResults) {
        res.sendResponse(paymentResults, 'Receive payment', 200);
    })
    .catch(function (error) {
        res.sendError({error}, error.message, 200);
    })
}

const createWallet = async (req, res) => {
    const keypair = StellarSdk.Keypair.random();
    const address = {
        stellarAddress: keypair.publicKey(),
        stellarSeed: keypair.secret()
    }
    await createAccountInLedger(keypair.publicKey());
    res.sendResponse({address}, 'Address created successfully.', 200);
};

const createAccountInLedger = async (newAccount) => {
    return new Promise(async (resolve, reject) => {
        try {
            // const admin = await getAdmin();
    
            const provisionerKeyPair = StellarSdk.Keypair.fromSecret(process.env.SEED)
            const provisioner = await stellarServer.loadAccount(provisionerKeyPair.publicKey())
        
            console.log('creating account in ledger', newAccount)

            const fee = await stellarServer.fetchBaseFee();
            const transaction = new StellarSdk.TransactionBuilder(provisioner, { fee })
                .addOperation(
                    StellarSdk.Operation.createAccount({
                    destination: newAccount,
                    startingBalance: '1'
                })
                ).setTimeout(0)
                .build()
      
            transaction.sign(provisionerKeyPair)
        
            const result = await stellarServer.submitTransaction(transaction);
            resolve(result);
            } catch (e) {
            console.log('Stellar account not created.', e)
        }
    })
}

const getBalance = async (req, res) => {
    stellarServer.accounts()
        .accountId(req.params.address)
        .call()
        .then((response) => {
            res.sendResponse(response.balances, 'Get balance - success.', 200);
        })
        .catch((error) => {
            res.sendError({error}, error.message, 200);
        });
};

const transferAmount = async (req, res) => {
    const signerKeys = StellarSdk.Keypair.fromSecret(req.body.password);
    const account = await stellarServer.loadAccount(signerKeys.publicKey());
    let to = req.body.to;
    const fee = await stellarServer.fetchBaseFee();
    let transaction = new StellarSdk.TransactionBuilder(account, { fee })
        .addOperation(
            StellarSdk.Operation.payment({
            destination: to,
            asset: StellarSdk.Asset.native(),
            amount: req.body.amount
            })
        ).setTimeout(0)
        .build()
  
    transaction.sign(signerKeys);

    try {
      const result = await stellarServer.submitTransaction(transaction)
      console.log(`sent ${result}`)
      return res.sendResponse({result}, 'Payment - success.', 200);
    } catch (error) {
      console.log(`failure ${e}`)
      return res.sendError(error, error.message, 500);
    }
 
}


module.exports = {
    createWallet
    , getBalance
    , transferAmount
    , receive
};